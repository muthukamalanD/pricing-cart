import "./styles.css";
import Cards from "./Cards";
export default function App() {
  return (
    <section className="pricing py-5">
      <div className="container">
        <Cards />
      </div>
    </section>
  );
}
